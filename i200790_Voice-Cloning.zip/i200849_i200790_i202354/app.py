import gradio as gr
import torch
import torchaudio
import soundfile as sf
from transformers import pipeline
from speechbrain.pretrained import EncoderClassifier

def extract_speaker_embedding(audio_path):
    try:
        classifier = EncoderClassifier.from_hparams(
            source="speechbrain/spkrec-xvect-voxceleb", 
            savedir="tmp"
        )
        signal, fs = torchaudio.load(audio_path)
        if fs != 16000:
            resample_transform = torchaudio.transforms.Resample(orig_freq=fs, new_freq=16000)
            signal = resample_transform(signal)
        if signal.shape[0] > 1:
            signal = signal.mean(dim=0, keepdim=True)
        if signal.ndim == 1:
            signal = signal.unsqueeze(0)
        embeddings = classifier.encode_batch(signal)
        speaker_embedding = embeddings.mean(dim=1).squeeze()
        return speaker_embedding
    except Exception as e:
        return f"Error extracting speaker embedding: {e}"

def synthesize_speech(audio_file, texts):
    try:
        # Extract speaker embedding
        speaker_embedding = extract_speaker_embedding(audio_file)
        if isinstance(speaker_embedding, str):  # Error during embedding extraction
            return speaker_embedding
        
        # Set up TTS pipeline
        device = 0 if torch.cuda.is_available() else -1
        synthesiser = pipeline("text-to-speech", model="microsoft/speecht5_tts", device=device)
        
        # Ensure embedding format
        if speaker_embedding.ndim == 1:
            speaker_embedding = speaker_embedding.unsqueeze(0)
        
        # Generate speech
        text_list = texts.split("\n")
        speech = synthesiser(
            text_list,
            forward_params={"speaker_embeddings": speaker_embedding}
        )
        
        # Save and return synthesized audio
        output_path = "synthesized_speech.wav"
        sf.write(output_path, speech[0]["audio"], samplerate=speech[0]["sampling_rate"])
        return output_path
    except Exception as e:
        return f"Error during speech synthesis: {e}"

def generate_audio(audio_file, text_input):
    output = synthesize_speech(audio_file, text_input)
    if output.endswith(".wav"):
        return output
    else:
        return f"Error: {output}"

# Gradio Interface
with gr.Blocks(css=".container {background-color: #f0f8ff;} .button {background-color: #00bfff; color: white; padding: 10px; border-radius: 5px;}") as demo:
    gr.Markdown("""
    # 🎙️ **Voice Cloning Application**
    Experience state-of-the-art voice cloning using deep learning!
    """, elem_classes="container")

    gr.Markdown("""
    ## 📂 **Step 1: Upload Reference Audio**
    Provide a short audio clip of the speaker whose voice you want to clone.
    """)
    audio_file = gr.Audio(label="Upload Reference Audio", type="filepath")

    gr.Markdown("""
    ## ✍️ **Step 2: Enter Text**
    Type the sentences you want to generate speech for. You can enter multiple sentences, each on a new line.
    """)
    text_input = gr.Textbox(
        label="Enter Text (separate multiple sentences with a new line)",
        placeholder="Type your sentences here..."
    )

    gr.Markdown("---")  # Adds a horizontal line separator

    gr.Markdown("""
    ## 🎧 **Step 3: Generate Cloned Speech**
    Click the button below to synthesize speech in the cloned voice.
    """)
    output_audio = gr.Audio(label="Synthesized Audio")

    synthesize_button = gr.Button("🎤 Synthesize Speech", elem_classes="button")
    synthesize_button.click(generate_audio, inputs=[audio_file, text_input], outputs=output_audio)

demo.launch(share=True)
