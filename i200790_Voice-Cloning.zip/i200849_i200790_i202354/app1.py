import gradio as gr
import torch
import torchaudio
import soundfile as sf
from transformers import pipeline
from speechbrain.pretrained import EncoderClassifier
import whisper

# Function to extract speaker embedding
def extract_speaker_embedding(audio_path):
    try:
        # Load a pre-trained speaker embedding model
        classifier = EncoderClassifier.from_hparams(
            source="speechbrain/spkrec-xvect-voxceleb", 
            savedir="tmp"
        )
        
        # Load audio file
        signal, fs = torchaudio.load(audio_path)
        
        # Resample if needed (most models prefer 16 kHz)
        if fs != 16000:
            resample_transform = torchaudio.transforms.Resample(
                orig_freq=fs, 
                new_freq=16000
            )
            signal = resample_transform(signal)
        
        # Ensure mono audio
        if signal.shape[0] > 1:
            signal = signal.mean(dim=0, keepdim=True)
        
        # Ensure the signal is 2D (batch, samples)
        if signal.ndim == 1:
            signal = signal.unsqueeze(0)
        
        # Generate speaker embedding
        embeddings = classifier.encode_batch(signal)
        speaker_embedding = embeddings.mean(dim=1)
        
        # Squeeze to remove unnecessary dimensions
        speaker_embedding = speaker_embedding.squeeze()
        
        return speaker_embedding
    
    except Exception as e:
        return str(f"Error extracting speaker embedding: {e}")

# Function to transcribe audio to text
def transcribe_audio(audio_path):
    try:
        # Load the pretrained Whisper model
        model = whisper.load_model("base")
        # Transcribe the audio using the model
        result = model.transcribe(audio_path)
        return result['text']
    except Exception as e:
        return str(f"Error transcribing audio: {e}")

# Function to synthesize speech
def synthesize_speech(
    text, 
    speaker_embedding, 
    output_path='synthesized_speech.wav', 
    model_name="microsoft/speecht5_tts"
):
    try:
        # Determine device
        device = 0 if torch.cuda.is_available() else -1
        
        # Initialize TTS pipeline
        synthesiser = pipeline(
            "text-to-speech", 
            model=model_name, 
            device=device
        )
        
        # Ensure speaker embedding is a 1D tensor
        if speaker_embedding.ndim == 1:
            speaker_embedding = speaker_embedding.unsqueeze(0)
        
        # Synthesize speech
        speech = synthesiser(
            [text], 
            forward_params={"speaker_embeddings": speaker_embedding}
        )
        
        # Save synthesized speech
        sf.write(
            output_path, 
            speech[0]["audio"], 
            samplerate=speech[0]["sampling_rate"]
        )
        
        return output_path
    
    except Exception as e:
        return str(f"Error synthesizing speech: {e}")
# Gradio function for the pipeline
def process_audio(reference_audio_path, input_audio_path):
    try:
        # Extract speaker embedding
        speaker_embedding = extract_speaker_embedding(reference_audio_path)
        if isinstance(speaker_embedding, str):  # Check for errors
            return speaker_embedding, None

        # Transcribe input audio
        transcribed_text = transcribe_audio(input_audio_path)
        if isinstance(transcribed_text, str) and transcribed_text.startswith("Error"):
            return transcribed_text, None

        # Use the first sentence of the transcription
        first_sentence = transcribed_text.split(".")[0].strip()

        # Synthesize speech
        output_file = synthesize_speech(
            first_sentence,
            speaker_embedding,
            output_path="synthesized_output.wav"
        )
        if isinstance(output_file, str) and output_file.startswith("Error"):
            return output_file, None

        return first_sentence, output_file

    except Exception as e:
        return str(f"Unexpected error: {e}"), None


# Create Gradio interface
interface = gr.Interface(
    fn=process_audio,
    inputs=[
        gr.Audio(label="Reference Audio (Target Voice)", type="filepath"),
        gr.Audio(label="Input Audio (To Transcribe)", type="filepath")
    ],
    outputs=[
        gr.Textbox(label="Transcribed First Sentence"),
        gr.Audio(label="Synthesized Speech")
    ],
    title="Voice Conversion Pipeline",
    description="Upload a reference audio file to extract voice characteristics and an input audio file for transcription. The system will synthesize the transcribed text in the reference voice."
)

# Launch the Gradio app
if __name__ == "__main__":
    interface.launch()

